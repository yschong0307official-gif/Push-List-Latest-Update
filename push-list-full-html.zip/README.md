# Push List Full HTML

Upload the following to the root of your GitHub repository:

- index.html
- assets/header.png

GitHub Pages:
Settings > Pages > Deploy from a branch > main > /(root)

The HTML contains all tour departures extracted from the supplied 10-page Push List PDF.
